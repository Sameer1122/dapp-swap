import React from "react";
import "./css/buysend.css";

function Send(props) {
    return (
        <div className="Send" style={{  height:"45%",borderRadius:"20px",top:"20%" ,backgroundColor:"rgba(38, 39,40 , 0.9)"}}>
            <div className="inputs" style={{ textAlign:"center" }}>
                <h3 className="txt">
                     YOUR RECEIPT  🚀
                    <br />
                    <strong style={{ marginRight:"30px" }}>
                    {props.code}

                    </strong>




                </h3>
               
                <h1 className="txt">
                
                </h1>





                <button onClick={props.settercode}>Close</button>


            </div>
        </div>
    );
}

export default Send;
