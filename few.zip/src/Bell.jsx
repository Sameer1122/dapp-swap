import React from "react";
import "./css/bell.css";
function Bell() {
  return (
    <div className="bell_call">
      <div className="noti">
        <h1 className="main-txt">Hello Fam</h1>
        <p className="main-data">New Nft Comming Soon</p>
      </div>
    </div>
  );
}

export default Bell;
